// #define GOOGLE_GLOG_DLL_DECL
// #include <glog/logging.h>
#include <iostream>
#include <fstream>
#include <eigen3/Eigen/Dense>
#include <glob.h>

#include "backend/problem.h"
#include "utils/tic_toc.h"

#ifdef USE_OPENMP

#include <omp.h>

#endif

using namespace std;

namespace myslam
{
    namespace backend
    {
        void Problem::LogoutVectorSize()
        {
            // LOG(INFO) <<
            //           "1 problem::LogoutVectorSize verticies_:" << verticies_.size() <<
            //           " edges:" << edges_.size();
        }

        Problem::Problem(ProblemType problemType) : problemType_(problemType)
        {
            LogoutVectorSize(); // ???? 
            verticies_marg_.clear();
        }

        Problem::~Problem() {}

        bool Problem::AddVertex(std::shared_ptr<Vertex> vertex)
        {
            if (verticies_.find(vertex->Id()) != verticies_.end())
            {
                // LOG(WARNING) << "Vertex " << vertex->Id() << " has been added before";
                return false;
            }
            else
            {
                verticies_.insert(pair<unsigned long, shared_ptr<Vertex>>(vertex->Id(), vertex));
            }

            return true;
        }

        bool Problem::AddEdge(shared_ptr<Edge> edge)
        {
            if (edges_.find(edge->Id()) == edges_.end())
            {
                edges_.insert(pair<ulong, std::shared_ptr<Edge>>(edge->Id(), edge));
            }
            else
            {
                // LOG(WARNING) << "Edge " << edge->Id() << " has been added before!";
                return false;
            }

            for (auto &vertex : edge->Verticies())
            {
                vertexToEdge_.insert(pair<ulong, shared_ptr<Edge>>(vertex->Id(), edge));
            }
            return true;
        }

        bool Problem::Solve(int iterations)
        {
            lambdas.clear();   
            
            if (edges_.size() == 0 || verticies_.size() == 0)
            {
                std::cerr << "\nCannot solve problem without edges or verticies" << std::endl;
                return false;
            }

            TicToc t_solve;
            // ????????????? H ?????
            SetOrdering();
            std::cout << "Problem Total ordering_generic: " << ordering_generic_ << std::endl;
            // ??edge, ?? H = J^T * J ???LM????J^T * J + \lambda I???H
            MakeHessian();
            // LM ???
            ComputeLambdaInitLM();
            // LM ??????
            bool stop = false;
            int iter = 0;
            while (!stop && (iter < iterations))
            {
                std::cout << "iter: " << iter << " , chi= " << currentChi_ << " , Lambda= " << currentLambda_
                          << std::endl;
                // ??lambda
                lambdas.push_back(currentLambda_);
                bool oneStepSuccess = false;
                int false_cnt = 0;
                while (!oneStepSuccess) // ???? Lambda, ????????
                {
                    // setLambda
                    AddLambdatoHessianLM();  // ?LM???lambda??????
                    // ????????? H X = B
                    SolveLinearSystem();
                    //
                    RemoveLambdaHessianLM();

                    // ??????1? delta_x_ ?????
                    if (delta_x_.squaredNorm() <= 1e-6 || false_cnt > 10)
                    {
                        stop = true;
                        break;
                    }

                    // ????? X = X+ delta_x
                    UpdateStates();
                    // ??????????? LM ? lambda ????
                    oneStepSuccess = IsGoodStepInLM();
                    // ?????
                    if (oneStepSuccess)
                    {
                        // ?????? ?? hessian
                        MakeHessian();
                        // TODO:: ????????????? b_max <= 1e-12 ?????????????????????????
                        //                double b_max = 0.0;
                        //                for (int i = 0; i < b_.size(); ++i) {
                        //                    b_max = max(fabs(b_(i)), b_max);
                        //                }
                        //                // ??????2? ???? b_max ??????????
                        //                stop = (b_max <= 1e-12);
                        false_cnt = 0;
                    }
                    else
                    {
                        false_cnt++;
                        RollbackStates(); // ????????
                    }
                }
                iter++;

                // ??????3? currentChi_ ?????chi2?????? 1e6 ????
                if (sqrt(currentChi_) <= stopThresholdLM_)
                    stop = true;
            }
            std::cout << "problem solve cost: " << t_solve.toc() << " ms" << std::endl;
            std::cout << "   makeHessian cost: " << t_hessian_cost_ << " ms" << std::endl;
            return true;
        }

        void Problem::SetOrdering()
        {

            // ??????
            ordering_poses_ = 0;
            ordering_generic_ = 0;
            ordering_landmarks_ = 0;

            // Note:: verticies_ ? map ???, ????? id ????
            // ??????????????
            for (auto vertex : verticies_)
            {
                ordering_generic_ += vertex.second->LocalDimension(); // ??????????
            }
        }

        void Problem::MakeHessian()
        {
            TicToc t_h;
            // ?????? H ??
            ulong size = ordering_generic_;
            MatXX H(MatXX::Zero(size, size));   // Hessian = J^T * J + \lambda I in LM
            VecX b(VecX::Zero(size));   // b = - J^T * r

            // TODO:: accelate, accelate, accelate
            // #ifdef USE_OPENMP
            // #pragma omp parallel for
            // #endif

            // ?????????????????????? H = J^T * J
            for (auto &edge : edges_)
            {
                // edge???pair?first???id?second?????
                edge.second->ComputeResidual();
                edge.second->ComputeJacobians();

                auto jacobians = edge.second->Jacobians();
                auto verticies = edge.second->Verticies();
                assert(jacobians.size() == verticies.size());
                for (size_t i = 0; i < verticies.size(); ++i)
                {
                    auto v_i = verticies[i];
                    if (v_i->IsFixed())
                        continue; // Hessian ???????????????????? 0

                    auto jacobian_i = jacobians[i];
                    ulong index_i = v_i->OrderingId();
                    ulong dim_i = v_i->LocalDimension();

                    MatXX JtW = jacobian_i.transpose() * edge.second->Information();
                    for (size_t j = i; j < verticies.size(); ++j)
                    {
                        auto v_j = verticies[j];

                        if (v_j->IsFixed())
                            continue;

                        auto jacobian_j = jacobians[j];
                        ulong index_j = v_j->OrderingId();
                        ulong dim_j = v_j->LocalDimension();

                        assert(v_j->OrderingId() != -1);
                        MatXX hessian = JtW * jacobian_j;
                        // ???????????
                        H.block(index_i, index_j, dim_i, dim_j).noalias() += hessian;
                        if (j != i)
                        {
                            // ??????
                            H.block(index_j, index_i, dim_j, dim_i).noalias() += hessian.transpose();
                        }
                    }
                    b.segment(index_i, dim_i).noalias() -= JtW * edge.second->Residual();
                }
            }
            Hessian_ = H;
            b_ = b;
            t_hessian_cost_ += t_h.toc();

            delta_x_ = VecX::Zero(size); // initial delta_x = 0_n;
        }

        /*
         * Solve Hx = b, we can use PCG iterative method or use sparse Cholesky
         */
        void Problem::SolveLinearSystem()
        {

            delta_x_ = Hessian_.inverse() * b_;
            //        delta_x_ = H.ldlt().solve(b_);
        }

        void Problem::UpdateStates()
        {
            for (auto vertex : verticies_)
            {
                ulong idx = vertex.second->OrderingId();
                ulong dim = vertex.second->LocalDimension();
                VecX delta = delta_x_.segment(idx, dim);

                // ????? x ??????  x_{k+1} = x_{k} + delta_x
                vertex.second->Plus(delta);
            }
        }

        void Problem::RollbackStates()
        {
            for (auto vertex : verticies_)
            {
                ulong idx = vertex.second->OrderingId();
                ulong dim = vertex.second->LocalDimension();
                VecX delta = delta_x_.segment(idx, dim);

                // ???????????????????????????????????????????
                vertex.second->Plus(-delta);
            }
        }

        /// LM
        void Problem::ComputeLambdaInitLM()
        {
            ni_ = 2.;
            currentLambda_ = -1.;
            currentChi_ = 0.0;
            // TODO:: robust cost chi2
            for (auto edge : edges_)
            {
                currentChi_ += edge.second->Chi2();
            }
            if (err_prior_.rows() > 0)
                currentChi_ += err_prior_.norm();

            stopThresholdLM_ = 1e-6 * currentChi_; // ????? ???? 1e-6 ?

            double maxDiagonal = 0;
            ulong size = Hessian_.cols();
            assert(Hessian_.rows() == Hessian_.cols() && "Hessian is not square");
            for (ulong i = 0; i < size; ++i)
            {
                maxDiagonal = std::max(fabs(Hessian_(i, i)), maxDiagonal);
            }
            double tau = 1e-5;
            currentLambda_ = tau * maxDiagonal;
        }

        void Problem::AddLambdatoHessianLM()
        {
            ulong size = Hessian_.cols();
            assert(Hessian_.rows() == Hessian_.cols() && "Hessian is not square");
            for (ulong i = 0; i < size; ++i)
            {
                Hessian_(i, i) += currentLambda_;   // ??? H = H + \lambda I??????????? lambda
            }
        }

        void Problem::RemoveLambdaHessianLM()
        {
            ulong size = Hessian_.cols();
            assert(Hessian_.rows() == Hessian_.cols() && "Hessian is not square");
            // TODO:: ????????????????????????????????????lambda???????????
            for (ulong i = 0; i < size; ++i)
            {
                Hessian_(i, i) -= currentLambda_;
            }
        }

        // // bool Problem::IsGoodStepInLM()
        // // {
        // //     double scale = 0;
        // //     scale = delta_x_.transpose() * (currentLambda_ * delta_x_ + b_);
        // //     scale += 1e-3; // make sure it's non-zero :)    // 
        // //     // recompute residuals after update state
        // //     // ???????
        // //     double tempChi = 0.0;
        // //     for (auto edge : edges_)
        // //     {
        // //         edge.second->ComputeResidual();
        // //         tempChi += edge.second->Chi2();
        // //     }   // 
        // //     // Nielson??
        // //     double rho = (currentChi_ - tempChi) / scale;
        // //     if (rho > 0 && isfinite(tempChi)) // last step was good, ?????
        // //     {
        // //         double alpha = 1. - pow((2 * rho - 1), 3);
        // //         alpha = std::min(alpha, 2. / 3.);
        // //         double scaleFactor = (std::max)(1. / 3., alpha);
        // //         currentLambda_ *= scaleFactor;
        // //         ni_ = 2;
        // //         currentChi_ = tempChi;
        // //         return true;
        // //     }
        // //     else
        // //     {
        // //         currentLambda_ *= ni_;
        // //         ni_ *= 2;
        // //         return false;
        // //     }
        // // }

        // todo ????????? from?https://blog.csdn.net/qq_37340588/article/details/107494444
        bool Problem::IsGoodStepInLM()
        {
            double scale = 0;
            scale = delta_x_.transpose() * (currentLambda_ * delta_x_ + b_);
            scale += 1e-3; // make sure it's non-zero :)

            // recompute residuals after update state
            // ???????
            double tempChi = 0.0;
            for (auto edge : edges_)
            {
                edge.second->ComputeResidual();
                tempChi += edge.second->Chi2();
            }

            //??
            RollbackStates();

            //??alpha
            VecX tempDelta = delta_x_;
            double alpha_ = b_.transpose() * delta_x_;
            alpha_ /= (tempChi-currentChi_)/2 + 2*b_.transpose()*delta_x_;
            alpha_ += 1e-1;
            delta_x_ = delta_x_ * alpha_;
            UpdateStates();

            tempChi = 0.0;
            for (auto edge: edges_) {
                edge.second->ComputeResidual();
                tempChi += edge.second->Chi2();
            }
            scale = delta_x_.transpose() * (currentLambda_ * delta_x_ + b_);
            scale += 1e-3;    // make sure it's non-zero :)
            
            double rho = (currentChi_ - tempChi) / scale;
            if (rho > 0 && isfinite(tempChi))   // last step was good, ?????
            {
                currentLambda_ = max(currentLambda_/(1+alpha_),1e-7);
                currentChi_ = tempChi;
                return true;
            } else {
                currentLambda_ += abs(tempChi-currentChi_)/(2*alpha_);
                return false;
            }

        }

        /** @brief conjugate gradient with perconditioning
         *
         *  the jacobi PCG method
         *
         */
        VecX Problem::PCGSolver(const MatXX &A, const VecX &b, int maxIter = -1)
        {
            assert(A.rows() == A.cols() && "PCG solver ERROR: A is not a square matrix");
            int rows = b.rows();
            int n = maxIter < 0 ? rows : maxIter;
            VecX x(VecX::Zero(rows));
            MatXX M_inv = A.diagonal().asDiagonal().inverse();
            VecX r0(b); // initial r = b - A*0 = b
            VecX z0 = M_inv * r0;
            VecX p(z0);
            VecX w = A * p;
            double r0z0 = r0.dot(z0);
            double alpha = r0z0 / p.dot(w);
            VecX r1 = r0 - alpha * w;
            int i = 0;
            double threshold = 1e-6 * r0.norm();
            while (r1.norm() > threshold && i < n)
            {
                i++;
                VecX z1 = M_inv * r1;
                double r1z1 = r1.dot(z1);
                double belta = r1z1 / r0z0;
                z0 = z1;
                r0z0 = r1z1;
                r0 = r1;
                p = belta * p + z1;
                w = A * p;
                alpha = r1z1 / p.dot(w);
                x += alpha * p;
                r1 -= alpha * w;
            }
            return x;
        }

    }
}
